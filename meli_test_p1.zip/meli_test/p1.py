#!/bin/python3

import math
import os
import random
import re
import sys

# Complete the flatlandSpaceStations function below.
def flatlandSpaceStations(n, c):
    rta = 0
    c_sorted = c
    c_sorted.sort()
    
    for x in range(0, len(c_sorted) - 1 ):
        p_rta = (c_sorted[x+1] - c_sorted[x]) // 2
        rta = max(rta, p_rta)
    
    rta = max(rta, c_sorted[0], (n - 1) - c_sorted[-1])
    
    return rta

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    nm = input().split()

    n = int(nm[0])

    m = int(nm[1])

    c = list(map(int, input().rstrip().split()))
    
    if 1 <= n <= 10**5 and 1 <= m <= n and len(c) > 0 and (len(c) == len(set(c))):
        result = flatlandSpaceStations(n, c)
    else:
        result = 0

    fptr.write(str(result) + '\n')

    fptr.close()
